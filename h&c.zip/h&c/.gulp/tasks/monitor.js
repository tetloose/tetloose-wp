import { watch, series } from 'gulp'
import { reload } from './serve.js'
import sprite from './sprite.js'
import { favicon } from './favicons.js'
import fonts from './fonts'
import { iconMoveFont, iconGenerate } from './icons.js'
import { compressAssets } from './images.js'
import { scriptsLint, scriptsBundle } from './scripts.js'
import { stylesLint, stylesDev, stylesPrint } from './styles.js'
import config from '../config'

const monitor = (cb) => {
    watch([config.scripts.files, config.scripts.modules],
        series(
            scriptsLint,
            scriptsBundle,
            reload
        )
    )
    watch([config.styles.files],
        series(
            stylesLint,
            stylesDev,
            stylesPrint
        )
    )
    watch([config.icons.fonts, config.icons.json],
        series(
            iconMoveFont,
            iconGenerate,
            stylesLint,
            stylesDev,
            stylesPrint,
            config.icons.success
        )
    )
    watch([config.html.files],
        series(reload)
    )
    watch([config.sprite.entry],
        series(
            sprite,
            stylesLint,
            stylesDev,
            stylesPrint,
            config.sprite.success
        )
    )
    watch([config.images.files],
        series(
            compressAssets,
            config.images.success
        )
    )
    watch(
        [config.favicons.entry],
        series(
            favicon,
            config.favicons.success,
            reload
        )
    )
    watch(
        [config.fonts.files],
        series(
            fonts,
            stylesLint,
            stylesDev,
            stylesPrint,
            config.fonts.success
        )
    )
    cb()
}

export default monitor
