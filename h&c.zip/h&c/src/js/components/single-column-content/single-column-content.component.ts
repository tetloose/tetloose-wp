
import { createModule, AppendModule } from '../../utilities/css-modules.utilities'
import styles from './single-column-content.module.scss'
import { row, col } from '../../markup/grid'

class SingleColumnContent {
    module: HTMLElement
    modifyers?: string
    content?: string
    type?: string
    state: {
        [key: string]: string
    }

    constructor(module: HTMLElement) {
        this.module = module
        this.modifyers = module.dataset.modifyers
        this.content = module.dataset.content
        this.type = module.dataset.type
        this.state = {
            initial: 'Css modules',
            clicked: ' is some sweet jazz'
        }

        if (this.modifyers) {
            this.modifyers.split(' ')
                .forEach(name => name && this.module.classList.add(name))
        }

        this.styleComponent()

        this.createMarkup()
    }

    styleComponent() {
        this.module.classList.add(styles.scc)
    }

    createMarkup() {
        const column1 = col(
            `
            <div class="${this.type && this.type}">
                ${this.content && this.content}
            </div>
            `,
            'is-half'
        )
        const column2 = col(
            `
            <div class="${this.type && this.type}">
                ${this.content && this.content}2
            </div>
            `,
            'is-half'
        )

        const markup = row([column1, column2], 'is-centered')

        new AppendModule(
            this.module,
            createModule(markup)
        )

        // this.eventListeners('js-click')
    }

    // eventListeners(elem: string) {
    //     document.querySelector(`.${ elem }`)?.addEventListener('click', (e: Event): void => {
    //         const { target } = e

    //         if (target instanceof HTMLElement) {
    //             target.innerHTML += this.state.clicked
    //             target.style.backgroundColor = 'orange'
    //         }
    //     })
    // }
}

export default (module: HTMLElement) => new SingleColumnContent(module)
