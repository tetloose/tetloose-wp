export function row(columns: string, modifyers?: string): string {
    return `
        <div class="${modifyers ? `l-row ${modifyers}` : 'l-row'}">
            ${columns}
        </div>
    `
}

export function col(content: string, modifyers?: string): string {
    return `
        <div class="${modifyers ? `l-row__col ${modifyers}` : 'l-row__col'}">
            ${content}
        </div>
    `
}
