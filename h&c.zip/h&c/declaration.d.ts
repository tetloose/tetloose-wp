declare module '*.module.scss'
